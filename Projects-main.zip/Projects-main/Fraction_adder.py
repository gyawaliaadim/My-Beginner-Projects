def main():
    print("Hello,")
    print("First Fraction")
    print("Type this number in this place.")
    print("  |")
    print("  |")
    print("  \/")
    print("  0")
    print("______")
    print("  0  ")
    d=int(input("Your choice: "))
    print("  0")
    print("_____")
    print("  0 ")
    print(" /\ ")
    print("  | ")
    print("  | ")
    print("Type this number in this place.")
    b=int(input("Your choice: "))
    print("Next fraction")
    print("Type this number in this place.")
    print("  |")
    print("  |")
    print("  \/")
    print("  0")
    print("______")
    print("  0  ")
    z=int(input("Your choice: "))
    print("  0")
    print("_____")
    print("  0 ")
    print(" /\ ")
    print("  | ")
    print("  | ")
    print("Type this number in this place.")
    x=int(input("Your choice: "))
    a=d*x
    don=b*x
    mon=b*z
    ton=b*x
    z=mon+a

    print(z)
    print("____")
    print(ton)
    input()
    main()
print(main())




